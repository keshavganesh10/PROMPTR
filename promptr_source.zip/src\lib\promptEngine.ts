import { type TargetModel, type PromptMode } from './constants';
import { type CheatCode, getCheatCodesByPlacement } from './cheatCodes';
import { analyzeInput, getDomainLabel, getTaskTypeLabel, type InputAnalysis } from './inputAnalyzer';
import { getDomainRole, getDomainTaskSteps, getDomainRules, getDomainChecklist, buildContextSection } from './domainTemplates';

export interface PromptInput {
  userText: string;
  model: TargetModel;
  mode: PromptMode;
  selectedCheatCodes: string[];
  // Lenz-specific fields
  lenzTopic?: string;
  lenzStuckPoint?: string;
}

export interface EngineResult {
  prompt: string;
  explanations: ExplanationItem[];
  isVague: boolean;
  coachingQuestions?: string[];
}

export interface ExplanationItem {
  technique: string;
  reason: string;
  icon: string;
}

// ─────────────────────────────────────────────
// Vagueness Detection (Enhanced)
// ─────────────────────────────────────────────
function detectVagueness(input: string): { isVague: boolean; questions: string[] } {
  const trimmed = input.trim();
  const words = trimmed.split(/\s+/);
  const questions: string[] = [];

  // Check 1: Word count threshold (raised from 8 to 10)
  if (words.length < 10) {
    questions.push('Could you describe your goal in more detail? What specifically should the AI produce — a document, code, analysis, plan, or something else?');
  }

  // Check 2: Audience / reader / user mention
  const hasAudience = /audience|reader|user|customer|viewer|student|developer|stakeholder|client|team|manager|executive/i.test(trimmed);
  if (!hasAudience) {
    questions.push('Who is the target audience for this output? (e.g., developers, executives, students, general public)');
  }

  // Check 3: Constraints, format, or style mention
  const hasConstraint = /must|should|always|never|constraint|limit|format|style|tone|voice|length|word count|paragraph|bullet|markdown|json|csv/i.test(trimmed);
  if (!hasConstraint) {
    questions.push('Are there any strict constraints? (e.g., tone, format, length, things to avoid, required structure)');
  }

  // Check 4: Context or background for shorter inputs
  const hasContext = /because|context|background|situation|currently|project|we are|our team|the goal|the problem|scenario/i.test(trimmed);
  if (!hasContext && words.length < 20) {
    questions.push('Can you provide some background context? What is the broader situation or project this fits into?');
  }

  // Check 5: Clear deliverable verb
  const hasDeliverable = /\b(write|build|create|analyse|analyze|review|design|draft|generate|produce|develop|compose|outline|summarise|summarize|refactor|implement|plan|propose|evaluate|compare|explain|describe)\b/i.test(trimmed);
  if (!hasDeliverable && words.length < 25) {
    questions.push('What exactly should the AI deliver? Try starting with an action verb like "write", "build", "analyse", "design", or "create".');
  }

  return {
    isVague: questions.length >= 2,
    questions,
  };
}

// ─────────────────────────────────────────────
// Claude Prompt Builder (XML-Structured)
// ─────────────────────────────────────────────
function buildClaudePrompt(
  input: string,
  mode: PromptMode,
  cheatCodes: string[]
): { prompt: string; explanations: ExplanationItem[] } {
  const explanations: ExplanationItem[] = [];
  const startCodes = getCheatCodesByPlacement('start', cheatCodes);
  const rulesCodes = getCheatCodesByPlacement('rules', cheatCodes);
  const endCodes = getCheatCodesByPlacement('end', cheatCodes);
  const analysis = analyzeInput(input);

  let prompt = '';

  if (mode === 'builder') {
    // ── BUILDER MODE (Claude) — Domain-Aware ──────────────────
    let roleContent = getDomainRole(analysis);

    roleContent += `\n\nYour methodology is rooted in first-principles thinking: you decompose every request into its atomic requirements, validate assumptions before acting, and produce output that is not merely correct but exemplary. You treat every deliverable as if it will be reviewed by the most demanding stakeholder in the room.`;

    if (startCodes.length > 0) {
      roleContent += '\n\n' + startCodes.map((c) => c.injection).join('\n\n');
      explanations.push({
        technique: 'Persona Enrichment',
        reason: `Injected ${startCodes.length} persona-deepening directive(s) into the role definition. Claude processes role instructions first in its attention hierarchy, making them the most influential framing for all subsequent output.`,
        icon: '🎭',
      });
    }

    prompt += `<role>\n${roleContent}\n</role>\n\n`;

    // Context section — enriched with structured fields
    const contextContent = buildContextSection(analysis, input);
    prompt += `<context>\nThe user has requested the following deliverable. Read it carefully, identify every explicit and implicit requirement, and ensure your output addresses each one:\n\n${contextContent}\n</context>\n\n`;

    // Task section — domain-specific steps
    const taskSteps = getDomainTaskSteps(analysis);
    prompt += `<task>\nCreate the deliverable described above by following these steps:\n${taskSteps.map((s, i) => `${i + 1}. ${s}`).join('\n')}\n</task>\n\n`;

    // Rules section — domain-specific rules
    const rules = getDomainRules(analysis);
    rulesCodes.forEach((c) => rules.push(c.injection));
    prompt += `<rules>\n${rules.map((r, i) => `${i + 1}. ${r}`).join('\n')}\n</rules>\n\n`;

    prompt += `<thinking>\nBefore producing your final output, reason through the following inside <thinking> tags:\n- What is the user ACTUALLY trying to accomplish (not just what they literally asked for)?\n- What are the 3 most likely edge cases or failure modes specific to this ${getDomainLabel(analysis.domain).toLowerCase()} task?\n- Is there a meaningfully better structure or approach than my first instinct?\n- What would the harshest critic in the ${getDomainLabel(analysis.domain).toLowerCase()} field say is missing from my output?\n- Have I made any assumptions that I should flag explicitly?\nDo NOT include these thinking tags in your final visible response.\n</thinking>\n\n`;

    prompt += `<output_format>\nBegin your response directly with the substantive deliverable — no preamble, no "Sure!", no "Here's what I came up with". Structure the output with clear headings and logical flow. If the deliverable has multiple components, use numbered sections or clear visual separators. End with any caveats, assumptions, or recommendations that add value.\n</output_format>\n\n`;

    // Quality checklist — domain-specific
    const checklist = getDomainChecklist(analysis);
    prompt += `<quality_checklist>\nBefore finalising your response, verify:\n${checklist.map(c => `☐ ${c}`).join('\n')}\n</quality_checklist>`;

    if (endCodes.length > 0) {
      prompt += '\n\n<additional_constraints>\n' + endCodes.map((c) => c.injection).join('\n\n') + '\n</additional_constraints>';
    }

    explanations.push(
      {
        technique: `Domain-Specific Role: ${getDomainLabel(analysis.domain)}`,
        reason: `Detected "${analysis.domain}" domain from your input keywords${analysis.detectedTechnologies.length > 0 ? ` (${analysis.detectedTechnologies.join(', ')})` : ''}. The role definition was tailored to a senior ${getDomainLabel(analysis.domain).toLowerCase()} expert instead of a generic "expert creator", which calibrates Claude's depth and domain vocabulary far more precisely.`,
        icon: '🏷️',
      },
      {
        technique: 'Separated Context & Task Tags',
        reason: 'By isolating the user\'s input in <context> and the step-by-step methodology in <task>, Claude processes WHAT to do and HOW to do it as distinct instruction streams. This reduces instruction bleed and ensures neither the goal nor the method is lost.',
        icon: '📋',
      },
      {
        technique: `Domain-Tailored Task Steps (${getDomainLabel(analysis.domain)})`,
        reason: `The ${taskSteps.length} task steps are specific to ${getDomainLabel(analysis.domain).toLowerCase()} work — not generic instructions. Each step addresses a domain-specific concern (${taskSteps[0].substring(0, 60)}...) ensuring the AI follows a methodology actual professionals use.`,
        icon: '📝',
      },
      {
        technique: `${getDomainLabel(analysis.domain)} Rules & Constraints`,
        reason: `${rules.length} rules are tailored to ${getDomainLabel(analysis.domain).toLowerCase()} best practices${!analysis.hasAudience || !analysis.hasConstraints ? ', including rules that compensate for missing information (audience, constraints) by forcing the AI to infer and state assumptions' : ''}. Domain-specific constraints catch errors a generic prompt would miss.`,
        icon: '📏',
      },
      {
        technique: 'Forced Thinking Phase',
        reason: `The <thinking> tag forces Claude to reason before answering — specifically about intent, edge cases in ${getDomainLabel(analysis.domain).toLowerCase()}, structural alternatives, and blind spots. This dramatically reduces hallucinations and improves depth.`,
        icon: '🧠',
      },
      {
        technique: `${getDomainLabel(analysis.domain)} Quality Checklist`,
        reason: `The quality checklist is specific to ${getDomainLabel(analysis.domain).toLowerCase()} deliverables (e.g., "${checklist[0]}") rather than generic quality checks. Domain-specific verification catches the exact failure modes that matter for this type of work.`,
        icon: '✅',
      },
    );

    if (analysis.complexity !== 'simple') {
      explanations.push({
        technique: `Complexity: ${analysis.complexity.charAt(0).toUpperCase() + analysis.complexity.slice(1)}`,
        reason: `Your input was assessed as "${analysis.complexity}" complexity based on ${analysis.complexity === 'complex' ? 'multiple requirements, multi-step structure, and technical depth' : 'multiple requirements or multi-step structure'}. The engine selected a more comprehensive task decomposition to match.`,
        icon: '📊',
      });
    }
  } else if (mode === 'strategist') {
    // ── STRATEGIST MODE (Claude) ────────────────
    let roleContent = `You are a battle-hardened strategist and critical analyst with 20+ years of experience across venture capital, management consulting, product strategy, and operational leadership. You have evaluated over 500 business plans, reviewed hundreds of product strategies, and watched countless well-intentioned ideas fail for predictable reasons.

You are known for your brutal honesty. You do not soften feedback to spare feelings. You do not lead with empty praise. You treat sycophancy as a professional failing — if something is mediocre, you say so plainly and explain exactly why. Your value comes from telling people what their friends and colleagues will not.

Your analytical framework is evidence-based: every critique must be grounded in specific reasoning, real-world precedent, or logical deduction. You never dismiss an idea with vague negativity — you explain the precise mechanism by which it will fail and what would need to change to prevent that failure.`;

    if (startCodes.length > 0) {
      roleContent += '\n\n' + startCodes.map((c) => c.injection).join('\n\n');
      explanations.push({
        technique: 'Persona Enrichment',
        reason: `Injected ${startCodes.length} persona-deepening directive(s) into the strategist role. This amplifies the model's commitment to critical analysis over agreeableness.`,
        icon: '🎭',
      });
    }

    prompt += `<role>\n${roleContent}\n</role>\n\n`;

    prompt += `<context>\nThe user has submitted the following for strategic analysis and critical review. Your job is to stress-test it ruthlessly, not to validate it:\n\n${input}\n</context>\n\n`;

    prompt += `<task>\nProvide a comprehensive strategic critique by following this exact structure:\n\n1. EXECUTIVE SUMMARY (2-3 sentences): What is this, and what is your overall assessment in one blunt sentence?\n\n2. GENUINE STRENGTHS (2-3 points maximum): Identify what actually works. Do not pad this section — if there is only one genuine strength, list only one. Each strength must be specific and substantiated.\n\n3. BRUTAL OBJECTIONS (5-7 points): These are the hard truths. For each objection:\n   - State the problem in one clear sentence\n   - Explain WHY it is a problem (the mechanism of failure)\n   - Provide a real-world precedent or logical proof where possible\n   - Rate severity: [CRITICAL], [MAJOR], or [MODERATE]\n\n4. HIDDEN ASSUMPTIONS: List 3-5 assumptions the user is making that they may not realise they are making. For each, explain what happens if the assumption is wrong.\n\n5. COMPETITIVE & MARKET REALITY: How does this hold up against existing alternatives, competitors, or established solutions? Be specific.\n\n6. ACTIONABLE IMPROVEMENTS (ranked by impact): For each brutal objection above, provide a concrete, specific improvement. Do not offer vague advice like "do more research" — specify exactly what research, where, and what it should inform.\n\n7. BOTTOM LINE: One paragraph. Would you invest your own money/time/reputation in this? Why or why not?\n</task>\n\n`;

    const rules: string[] = [
      'ZERO sycophancy. Do not begin with "Great question!" or "This is interesting!" — begin with substance.',
      'Every critique must be SPECIFIC and EVIDENCE-GROUNDED. Vague negativity ("this needs work") is as useless as vague praise.',
      'Strengths section must be genuine — do not manufacture compliments to soften the blow. If there are no real strengths, say so directly.',
      'Objections must include the MECHANISM of failure, not just the prediction. Explain HOW and WHY something will fail.',
      'Challenge the user\'s fundamental assumptions, not just surface-level execution details.',
      'Improvements must be actionable within a reasonable timeframe and resource envelope. Do not suggest solutions that require unrealistic resources.',
      'If the idea is fundamentally flawed at its core premise, say so clearly in the Executive Summary. Do not bury the lead.',
      'Use plain, direct language. Avoid management jargon, buzzwords, and consultant-speak.',
      'Treat the user as a competent adult who can handle difficult feedback — do not condescend or over-explain obvious points.',
      'If you genuinely think the idea has merit, say so with equal conviction — contrarian praise is as valuable as contrarian critique.',
    ];
    rulesCodes.forEach((c) => rules.push(c.injection));

    prompt += `<rules>\n${rules.map((r, i) => `${i + 1}. ${r}`).join('\n')}\n</rules>\n\n`;

    prompt += `<thinking>\nBefore responding, reason through:\n- What is the user's REAL goal behind this idea/plan/strategy?\n- What are the 3 most likely reasons this will fail in the real world?\n- What assumptions is the user making without realising it?\n- Am I being genuinely critical or just performatively harsh? Calibrate.\n- What would someone who ACTUALLY tried this learn the hard way?\n</thinking>\n\n`;

    prompt += `<anti_sycophancy_check>\nBefore finalising, verify:\n☐ Your first sentence contains a substantive assessment, not a compliment\n☐ Each objection includes a specific failure mechanism\n☐ You have challenged at least one fundamental assumption\n☐ Your improvements are concrete enough to act on tomorrow\n☐ You have not softened language to avoid discomfort\n☐ Your overall tone is respectful but unflinching\n</anti_sycophancy_check>`;

    if (endCodes.length > 0) {
      prompt += '\n\n<additional_constraints>\n' + endCodes.map((c) => c.injection).join('\n\n') + '\n</additional_constraints>';
    }

    explanations.push(
      {
        technique: 'XML Role Tag with Anti-Sycophancy Framing',
        reason: 'The <role> tag defines a multi-paragraph strategist persona that explicitly names sycophancy as a professional failing. This counter-programmes Claude\'s default tendency toward agreeableness by making critical honesty part of the model\'s self-concept for this conversation.',
        icon: '🏷️',
      },
      {
        technique: 'Structured Critique Framework (7-Section)',
        reason: 'The task enforces a rigid seven-section critique structure: executive summary → strengths → brutal objections → hidden assumptions → competitive reality → improvements → bottom line. This prevents the model from defaulting to vague commentary and ensures every dimension of the idea is stress-tested.',
        icon: '📋',
      },
      {
        technique: 'Severity-Rated Objections',
        reason: 'Requiring [CRITICAL], [MAJOR], or [MODERATE] severity ratings forces the model to triage its critiques by impact, giving the user a clear sense of which problems to address first and which are secondary.',
        icon: '⚖️',
      },
      {
        technique: 'Evidence-Grounding Rules',
        reason: 'Rules requiring "specific reasoning, real-world precedent, or logical deduction" for every critique prevent the model from generating generic negativity. Each objection must earn its place through substantiation.',
        icon: '📏',
      },
      {
        technique: 'Hidden Assumptions Extraction',
        reason: 'Forcing the model to name assumptions the user did not explicitly state is one of the highest-value strategic exercises. It surfaces blind spots that are invisible from inside the idea.',
        icon: '🔍',
      },
      {
        technique: 'Anti-Sycophancy Verification Checklist',
        reason: 'The self-verification checklist forces Claude to audit its own output for sycophantic patterns before finalising. This acts as a final guardrail against the model\'s strong default tendency to validate and agree.',
        icon: '🧠',
      },
      {
        technique: 'Mechanism-of-Failure Requirement',
        reason: 'Requiring objections to explain HOW and WHY something will fail — not just that it will — transforms critique from opinion into analysis. The user gets diagnostic insight, not just a verdict.',
        icon: '🔬',
      },
      {
        technique: 'Actionable Improvement Pairing',
        reason: 'Every objection must be paired with a concrete, specific improvement. This ensures the critique is constructive rather than merely destructive, and gives the user a clear path forward.',
        icon: '🎯',
      },
    );
  } else {
    // mode === 'lenz' — handled separately by buildLenzPrompt, but fallback
    prompt = `<role>\nYou are a world-class university professor and Lenz tutor.\n</role>\n\n<task>\n${input}\n</task>`;
    explanations.push({
      technique: 'Lenz Fallback',
      reason: 'Lenz mode is handled by the dedicated Lenz prompt builder.',
      icon: '🎓',
    });
  }

  return { prompt, explanations };
}

// ─────────────────────────────────────────────
// OpenAI Prompt Builder (Markdown-Delimited)
// ─────────────────────────────────────────────
function buildOpenAIPrompt(
  input: string,
  mode: PromptMode,
  cheatCodes: string[]
): { prompt: string; explanations: ExplanationItem[] } {
  const explanations: ExplanationItem[] = [];
  const startCodes = getCheatCodesByPlacement('start', cheatCodes);
  const rulesCodes = getCheatCodesByPlacement('rules', cheatCodes);
  const endCodes = getCheatCodesByPlacement('end', cheatCodes);
  const analysis = analyzeInput(input);

  let prompt = '';

  if (mode === 'builder') {
    // ── BUILDER MODE (OpenAI) — Domain-Aware ──────────────────
    let role = getDomainRole(analysis);

    role += `\n\nYour working methodology combines first-principles decomposition with pragmatic execution: you break every request down to its atomic requirements, validate each assumption, choose the optimal approach from your extensive toolkit, and produce output that is not merely correct but exemplary — the kind of work that sets the quality bar for an entire team.`;

    if (startCodes.length > 0) {
      role += '\n\n' + startCodes.map((c) => c.injection).join('\n\n');
      explanations.push({
        technique: 'Hyper-Specific Role Enhancement',
        reason: `Enhanced the system role with ${startCodes.length} expertise-deepening directive(s). GPT-4o weights system-level role definitions heavily for calibrating the depth, confidence, and domain specificity of all subsequent output.`,
        icon: '🎭',
      });
    }

    prompt += `### System Role\n${role}\n\n`;

    const contextContent = buildContextSection(analysis, input);
    prompt += `### Context & Background\nThe user has submitted the following request. Read it carefully, identify every explicit and implicit requirement, and treat any ambiguity as an opportunity to demonstrate thoughtful interpretation:\n\n---\n${contextContent}\n---\n\n`;

    prompt += `### Primary Objective\nProduce a complete, polished, production-ready deliverable that fully addresses every aspect of the user's request. The output should require zero follow-up editing and should read as if it were prepared by a senior ${getDomainLabel(analysis.domain).toLowerCase()} professional billing for their time.\n\n`;

    const taskSteps = getDomainTaskSteps(analysis);
    prompt += `### Detailed Instructions\n${taskSteps.map((s, i) => `${i + 1}. **Step ${i + 1}**: ${s}`).join('\n')}\n\n`;

    const rules = getDomainRules(analysis);
    rulesCodes.forEach((c) => rules.push(c.injection));
    prompt += `### Quality Standards\n${rules.map((r) => `- ${r}`).join('\n')}\n\n`;

    prompt += `### Output Structure\nBegin your response directly with the substantive deliverable. Do not include preamble such as "Sure!", "Of course!", or "Here is what you asked for". Structure the output using clear headings and logical sections appropriate to the content type. Conclude with any caveats, assumptions, or bonus recommendations that add value.\n\n`;

    prompt += `### Anti-Patterns to Avoid\n- Starting your response with a meta-commentary about the task rather than the deliverable itself\n- Using filler phrases that add no information ("It's important to note that...", "As you may know...")\n- Providing generic advice when specific recommendations are possible\n- Over-qualifying every statement with unnecessary hedging ("This might potentially perhaps be...")\n- Producing a partial deliverable and asking the user if they want you to continue\n- Using inconsistent formatting or terminology across sections\n\n`;

    const checklist = getDomainChecklist(analysis);
    prompt += `### Self-Verification\nBefore finalising your response, confirm:\n${checklist.map(c => `- [ ] ${c}`).join('\n')}\n\n`;

    prompt += `### Tone & Voice\nConfident, precise, and professional. Write with the authority of someone who has done this hundreds of times. Be warm but not chatty. Be thorough but not verbose. Every sentence must earn its place.`;

    if (endCodes.length > 0) {
      prompt += '\n\n### Additional Requirements\n' + endCodes.map((c) => `- ${c.injection}`).join('\n');
    }

    explanations.push(
      {
        technique: `Domain-Specific Role: ${getDomainLabel(analysis.domain)}`,
        reason: `Detected "${analysis.domain}" domain from your input${analysis.detectedTechnologies.length > 0 ? ` (technologies: ${analysis.detectedTechnologies.join(', ')})` : ''}. GPT-4o received a role definition tailored to a senior ${getDomainLabel(analysis.domain).toLowerCase()} expert, dramatically improving domain vocabulary and depth.`,
        icon: '🏷️',
      },
      {
        technique: 'Fenced Context Block with Structured Fields',
        reason: `The user's input is wrapped in horizontal-rule fences (---) within the Context section${analysis.hasContext || analysis.hasAudience || analysis.hasConstraints || analysis.hasFormat ? ', enriched with extracted structured fields (audience, constraints, context, format)' : ''}. GPT-4o parses this as quoted input to operate upon, reducing instruction injection risk.`,
        icon: '📋',
      },
      {
        technique: `${taskSteps.length}-Step Domain Instructions`,
        reason: `${taskSteps.length} numbered steps guide GPT-4o through a systematic ${getDomainLabel(analysis.domain).toLowerCase()}-specific process. Each step addresses a domain-specific concern that generic instructions would miss.`,
        icon: '📝',
      },
      {
        technique: `${getDomainLabel(analysis.domain)} Quality Standards`,
        reason: `${rules.length} rules tailored to ${getDomainLabel(analysis.domain).toLowerCase()} best practices create a domain-specific constraint mesh. This catches errors unique to this field that a generic ruleset would overlook.`,
        icon: '📏',
      },
      {
        technique: `${getDomainLabel(analysis.domain)} Verification Checklist`,
        reason: `Domain-specific self-verification (e.g., "${checklist[0]}") ensures the output meets professional standards for ${getDomainLabel(analysis.domain).toLowerCase()} deliverables, not just generic quality checks.`,
        icon: '✅',
      },
      {
        technique: 'Tone & Voice Calibration',
        reason: 'Explicit stylistic guidance prevents GPT-4o from defaulting to its overly enthusiastic, chatty baseline. Specific anti-directives ("warm but not chatty, thorough but not verbose") create a bounded, professional voice.',
        icon: '🎯',
      },
    );

    if (analysis.complexity !== 'simple') {
      explanations.push({
        technique: `Complexity: ${analysis.complexity.charAt(0).toUpperCase() + analysis.complexity.slice(1)}`,
        reason: `Input assessed as "${analysis.complexity}" complexity. The engine selected a more comprehensive task decomposition to match the scope of your request.`,
        icon: '📊',
      });
    }
  } else if (mode === 'strategist') {
    // ── STRATEGIST MODE (OpenAI) ────────────────
    let role = `You are a battle-tested strategist and critical analyst with 20+ years of experience across venture capital, management consulting (McKinsey/BCG-tier), product strategy, and operational leadership. You have evaluated over 500 business plans, advised 50+ startups (half of which failed — you know exactly why), and served on advisory boards for Fortune 500 companies.

You are valued for one thing above all: you tell people what they need to hear, not what they want to hear. You treat sycophancy as professional malpractice. If an idea is mediocre, you say so plainly. If it has a fatal flaw, you name it in your first sentence. Your critiques are always grounded in evidence, precedent, or rigorous logic — never vague negativity.

You believe the most valuable thing you can give someone is a clear-eyed assessment that saves them from wasting months or years on a flawed approach.`;

    if (startCodes.length > 0) {
      role += '\n\n' + startCodes.map((c) => c.injection).join('\n\n');
      explanations.push({
        technique: 'Hyper-Specific Strategist Role',
        reason: `Enhanced the system role with ${startCodes.length} expertise-deepening directive(s). This amplifies the model's commitment to critical rigour over default agreeableness.`,
        icon: '🎭',
      });
    }

    prompt += `### System Role\n${role}\n\n`;

    prompt += `### Context & Background\nThe user has submitted the following for strategic analysis and critical review. Your job is to STRESS-TEST it, not to validate it:\n\n---\n${input}\n---\n\n`;

    prompt += `### Primary Objective\nDeliver an unflinching, evidence-grounded strategic critique that identifies fatal flaws, hidden assumptions, and competitive blind spots — paired with concrete, actionable improvements the user can execute immediately.\n\n`;

    prompt += `### Critique Framework (Follow This Structure Exactly)\n1. **Executive Summary** (2-3 sentences): What is this, and what is your overall assessment? Lead with the strongest point — positive or negative.\n2. **Genuine Strengths** (2-3 points, maximum): Only include strengths that are real and specific. Do not pad this section to be polite. If there is one genuine strength, list one.\n3. **Brutal Objections** (5-7 points): For each objection, provide:\n   - The problem in one clear sentence\n   - The failure mechanism: WHY this is a problem and HOW it leads to failure\n   - A real-world precedent or logical proof where possible\n   - Severity rating: [CRITICAL], [MAJOR], or [MODERATE]\n4. **Hidden Assumptions** (3-5 points): Assumptions the user is making without realising it. For each, explain the consequence if the assumption is wrong.\n5. **Competitive & Market Reality**: How does this hold up against existing alternatives? Name specific competitors or solutions.\n6. **Actionable Improvements** (ranked by impact): For each objection, a concrete improvement. Not "do more research" — specify what research, where, and what decision it should inform.\n7. **Bottom Line** (1 paragraph): Would you invest your own money, time, or reputation in this? Why or why not?\n\n`;

    prompt += `### Quality Standards\n- ZERO sycophancy — your first sentence must contain a substantive assessment, not a compliment\n- Every critique must be SPECIFIC and EVIDENCE-GROUNDED with a clear failure mechanism\n- Strengths must be genuine — do not manufacture praise to soften delivery\n- Challenge fundamental assumptions, not just surface-level execution\n- Improvements must be actionable within a realistic timeframe and resource envelope\n- Use plain, direct language — no management jargon, buzzwords, or consultant-speak\n- Treat the user as a competent adult who can handle hard truths\n`;
    rulesCodes.forEach((c) => {
      prompt += `- ${c.injection}\n`;
    });

    prompt += `\n### Anti-Patterns to Avoid\n- Beginning with "This is a great start!" or any variant of opening praise\n- Providing vague critiques without specific failure mechanisms ("this needs more work")\n- Softening language to avoid discomfort ("you might want to consider...")\n- Over-qualifying assessments with excessive hedging\n- Suggesting improvements that require unrealistic resources or timelines\n- Being contrarian for its own sake — if something genuinely works, say so\n\n`;

    prompt += `### Self-Verification\nBefore finalising, confirm:\n- [ ] First sentence is substantive, not complimentary\n- [ ] Each objection includes a specific failure mechanism\n- [ ] At least one fundamental assumption has been challenged\n- [ ] Improvements are concrete enough to act on within one week\n- [ ] Language has not been softened to avoid discomfort\n- [ ] Overall tone is respectful but unflinching`;

    if (endCodes.length > 0) {
      prompt += '\n\n### Additional Requirements\n' + endCodes.map((c) => `- ${c.injection}`).join('\n');
    }

    explanations.push(
      {
        technique: 'Anti-Sycophancy System Role',
        reason: 'The system role explicitly names sycophancy as "professional malpractice" and defines the persona\'s value proposition as telling people what they NEED to hear. This counter-programmes GPT-4o\'s strong default tendency toward agreeableness and validation.',
        icon: '🏷️',
      },
      {
        technique: 'Structured 7-Section Critique Framework',
        reason: 'A rigid seven-section structure (executive summary → strengths → objections → assumptions → competition → improvements → bottom line) prevents the model from defaulting to unstructured commentary and ensures comprehensive analysis.',
        icon: '📋',
      },
      {
        technique: 'Severity-Rated Objections',
        reason: 'Requiring [CRITICAL], [MAJOR], [MODERATE] severity tags forces triage by impact. The user immediately knows which problems to address first, transforming a wall of critique into a prioritised action plan.',
        icon: '⚖️',
      },
      {
        technique: 'Failure Mechanism Requirement',
        reason: 'Requiring the HOW and WHY of failure — not just the prediction — transforms critique from opinion into diagnostic analysis. The user receives insight into causal chains, not just verdicts.',
        icon: '🔬',
      },
      {
        technique: 'Hidden Assumptions Extraction',
        reason: 'Forcing the model to name unstated assumptions surfaces the blind spots that are invisible from inside an idea. This is consistently rated as the highest-value section by users of strategic analysis tools.',
        icon: '🔍',
      },
      {
        technique: 'Anti-Sycophancy Self-Verification',
        reason: 'The final checklist forces the model to audit its output for sycophantic patterns, softened language, and vague critique. This is the last line of defence against GPT-4o\'s deeply ingrained politeness defaults.',
        icon: '🧠',
      },
      {
        technique: 'Positive Anti-Pattern Framing',
        reason: 'Following OpenAI\'s own guidance, avoidance behaviours are listed in a dedicated section with clear examples. This "negative space" approach tells the model what the OUTPUT should NOT look like, complementing the positive instructions.',
        icon: '✅',
      },
      {
        technique: 'Concrete Improvement Pairing',
        reason: 'Pairing every objection with a specific, actionable improvement ensures the critique is constructive. The specificity requirement ("not \'do more research\' — specify what research") closes the most common escape hatch for lazy recommendations.',
        icon: '🎯',
      },
    );
  } else {
    // mode === 'lenz' — fallback
    prompt = `### System Role\nYou are a world-class university professor and Lenz tutor.\n\n### Task\n${input}`;
    explanations.push({
      technique: 'Lenz Fallback',
      reason: 'Lenz mode is handled by the dedicated Lenz prompt builder.',
      icon: '🎓',
    });
  }

  return { prompt, explanations };
}

// ─────────────────────────────────────────────
// Gemini Prompt Builder (Structured Sections)
// ─────────────────────────────────────────────
function buildGeminiPrompt(
  input: string,
  mode: PromptMode,
  cheatCodes: string[]
): { prompt: string; explanations: ExplanationItem[] } {
  const explanations: ExplanationItem[] = [];
  const startCodes = getCheatCodesByPlacement('start', cheatCodes);
  const rulesCodes = getCheatCodesByPlacement('rules', cheatCodes);
  const endCodes = getCheatCodesByPlacement('end', cheatCodes);
  const analysis = analyzeInput(input);

  let prompt = '';

  if (mode === 'builder') {
    // ── BUILDER MODE (Gemini) — Domain-Aware ──────────────────
    let role = getDomainRole(analysis);

    role += `\n\nYour methodology is rooted in first-principles thinking: decompose every request into atomic requirements, validate assumptions, choose the optimal approach, and execute with rigour. You are known for anticipating edge cases, handling ambiguity gracefully, and producing self-contained deliverables that require zero follow-up.`;

    if (startCodes.length > 0) {
      role += '\n\n' + startCodes.map((c) => c.injection).join('\n\n');
      explanations.push({
        technique: 'Role Enrichment',
        reason: `Injected ${startCodes.length} persona-deepening directive(s) into the role definition, amplifying Gemini's commitment to the specified expertise level and methodology.`,
        icon: '🎭',
      });
    }

    prompt += `**Role:** ${role}\n\n`;

    const contextContent = buildContextSection(analysis, input);
    prompt += `**Context & Input:**\nThe user has requested the following deliverable. Identify every explicit and implicit requirement before beginning:\n\n> ${contextContent}\n\n`;

    prompt += `**Primary Objective:** Produce a complete, polished, production-ready deliverable that fully addresses every aspect of the user's request. The output should require zero follow-up editing.\n\n`;

    const taskSteps = getDomainTaskSteps(analysis);
    prompt += `**Step-by-Step Approach:**\n${taskSteps.map((s, i) => `${i + 1}. ${s}`).join('\n')}\n\n`;

    const rules = getDomainRules(analysis);
    rulesCodes.forEach((c) => rules.push(c.injection));
    prompt += `**Quality Standards:**\n${rules.map((r) => `• ${r}`).join('\n')}\n\n`;

    prompt += `**Systematic Thinking:** Before producing your final output, consider multiple angles:\n• What is the user ACTUALLY trying to accomplish beyond what they literally asked?\n• What are the 3 most likely edge cases or failure modes in ${getDomainLabel(analysis.domain).toLowerCase()}?\n• Is there a better structure or approach than your first instinct?\n• What would a demanding ${getDomainLabel(analysis.domain).toLowerCase()} reviewer say is missing?\n\n`;

    prompt += `**Output Format:** Provide a well-structured, comprehensive response with clear headings and logical organisation. Begin directly with substantive content. End with any caveats, assumptions, or bonus recommendations.\n\n`;

    const checklist = getDomainChecklist(analysis);
    prompt += `**Self-Verification Checklist:**\n${checklist.map(c => `• ${c}`).join('\n')}`;

    if (endCodes.length > 0) {
      prompt += '\n\n**Additional Constraints:**\n' + endCodes.map((c) => `• ${c.injection}`).join('\n');
    }

    explanations.push(
      {
        technique: `Domain-Specific Role: ${getDomainLabel(analysis.domain)}`,
        reason: `Detected "${analysis.domain}" domain from your input${analysis.detectedTechnologies.length > 0 ? ` (${analysis.detectedTechnologies.join(', ')})` : ''}. Gemini received a role tailored to a senior ${getDomainLabel(analysis.domain).toLowerCase()} expert, improving domain accuracy.`,
        icon: '🏷️',
      },
      {
        technique: 'Blockquote Context with Structured Fields',
        reason: `The user's input is wrapped in a blockquote (>)${analysis.hasContext || analysis.hasAudience || analysis.hasConstraints || analysis.hasFormat ? ', enriched with structured fields' : ''}, creating a semantically distinct block that Gemini processes as input to operate upon.`,
        icon: '📋',
      },
      {
        technique: `${taskSteps.length}-Step ${getDomainLabel(analysis.domain)} Approach`,
        reason: `Domain-specific steps guide Gemini through a systematic ${getDomainLabel(analysis.domain).toLowerCase()} process. This leverages Gemini's strong performance with explicit procedural instructions.`,
        icon: '📝',
      },
      {
        technique: 'Multi-Angle Thinking Directive',
        reason: `Gemini benefits from explicit multi-perspective reasoning. The reflection prompts are tailored to ${getDomainLabel(analysis.domain).toLowerCase()} edge cases and review standards.`,
        icon: '🧠',
      },
      {
        technique: `${getDomainLabel(analysis.domain)} Quality Standards`,
        reason: `${rules.length} domain-specific rules create a constraint mesh tailored to ${getDomainLabel(analysis.domain).toLowerCase()} best practices.`,
        icon: '📏',
      },
      {
        technique: `${getDomainLabel(analysis.domain)} Verification Checklist`,
        reason: `Domain-specific checklist (e.g., "${checklist[0]}") catches the exact failure modes that matter for ${getDomainLabel(analysis.domain).toLowerCase()} work.`,
        icon: '✅',
      },
    );

    if (analysis.complexity !== 'simple') {
      explanations.push({
        technique: `Complexity: ${analysis.complexity.charAt(0).toUpperCase() + analysis.complexity.slice(1)}`,
        reason: `Input assessed as "${analysis.complexity}" complexity. More comprehensive task decomposition was selected accordingly.`,
        icon: '📊',
      });
    }
  } else if (mode === 'strategist') {
    // ── STRATEGIST MODE (Gemini) ────────────────
    let role = `You are a senior strategic adviser and critical analyst with 20+ years of experience across management consulting, venture capital, product strategy, and operational leadership. You cut through noise to identify what truly matters and deliver unflinching assessments grounded in evidence and logic.

You are known for brutal honesty. If something is mediocre, you say so. If an idea has a fatal flaw, you name it immediately. You never soften feedback to spare feelings — you treat sycophancy as a disservice to the person seeking your counsel. Your critiques are always specific, evidence-based, and paired with actionable improvements.`;

    if (startCodes.length > 0) {
      role += '\n\n' + startCodes.map((c) => c.injection).join('\n\n');
    }

    prompt += `**Role:** ${role}\n\n`;

    prompt += `**Context:** The user has submitted the following for strategic analysis. Your job is to stress-test it ruthlessly:\n\n> ${input}\n\n`;

    prompt += `**Critique Framework (follow this structure):**\n1. **Executive Summary** (2-3 sentences): Overall assessment, leading with the strongest point.\n2. **Genuine Strengths** (2-3 max): Real, specific strengths only. Do not pad.\n3. **Brutal Objections** (5-7): Each with problem statement, failure mechanism, severity [CRITICAL/MAJOR/MODERATE].\n4. **Hidden Assumptions** (3-5): Unstated assumptions and consequences if wrong.\n5. **Competitive Reality**: Specific competitors and existing alternatives.\n6. **Actionable Improvements** (ranked by impact): Concrete, specific, executable.\n7. **Bottom Line**: Would you invest your own resources? Why or why not?\n\n`;

    const rules: string[] = [
      'ZERO sycophancy — lead with substance, not compliments.',
      'Every critique must include a specific failure mechanism.',
      'Prioritise depth of analysis over breadth of coverage.',
      'Support every claim with reasoning, evidence, or precedent.',
      'Challenge fundamental assumptions, not just execution details.',
      'Improvements must be actionable within realistic constraints.',
      'Use plain, direct language — no jargon or buzzwords.',
      'If the idea genuinely has merit, say so with equal conviction.',
    ];
    rulesCodes.forEach((c) => rules.push(c.injection));

    prompt += `**Standards:**\n${rules.map((r) => `• ${r}`).join('\n')}\n\n`;

    prompt += `**Systematic Thinking:** Before responding, consider:\n• What are the 3 most likely reasons this will fail in the real world?\n• What assumptions is the user making without realising?\n• Am I being genuinely analytical or just performatively harsh?\n• What would someone who ACTUALLY tried this learn the hard way?\n\n`;

    prompt += `**Verification:**\n• First sentence contains substantive assessment, not a compliment\n• Each objection has a specific failure mechanism\n• At least one fundamental assumption challenged\n• Improvements are concrete enough to act on this week\n• Language is direct and unsoftened`;

    if (endCodes.length > 0) {
      prompt += '\n\n**Additional Constraints:**\n' + endCodes.map((c) => `• ${c.injection}`).join('\n');
    }

    explanations.push(
      {
        technique: 'Anti-Sycophancy Role Definition',
        reason: 'The role explicitly frames sycophancy as a disservice, counter-programming Gemini\'s default tendency toward agreeableness. The multi-paragraph backstory deepens the model\'s commitment to critical honesty.',
        icon: '🏷️',
      },
      {
        technique: '7-Section Critique Framework',
        reason: 'A rigid seven-section structure ensures comprehensive analysis: summary → strengths → objections → assumptions → competition → improvements → bottom line. This prevents unstructured commentary.',
        icon: '📋',
      },
      {
        technique: 'Severity Rating System',
        reason: '[CRITICAL/MAJOR/MODERATE] severity tags force triage by impact, giving the user a prioritised action plan rather than an undifferentiated list of concerns.',
        icon: '⚖️',
      },
      {
        technique: 'Multi-Angle Reflection',
        reason: 'Four specific reflection prompts force Gemini to consider failure modes, hidden assumptions, and analytical calibration before responding, improving the depth and rigour of the critique.',
        icon: '🧠',
      },
      {
        technique: 'Evidence-Grounding Requirements',
        reason: 'Rules requiring evidence, reasoning, or precedent for every claim prevent generic negativity and ensure each critique earns its place through substantiation.',
        icon: '📏',
      },
      {
        technique: 'Verification Checklist',
        reason: 'The final checklist audits for sycophantic patterns and vague critique, serving as a last guardrail against the model\'s politeness defaults.',
        icon: '✅',
      },
    );
  } else {
    // mode === 'lenz' — fallback
    prompt = `**Role:** You are a world-class university professor and Lenz tutor.\n\n**Task:** ${input}`;
    explanations.push({
      technique: 'Lenz Fallback',
      reason: 'Lenz mode is handled by the dedicated Lenz prompt builder.',
      icon: '🎓',
    });
  }

  return { prompt, explanations };
}

// ─────────────────────────────────────────────
// Lovable/v0 Prompt Builder (Spec-Style)
// ─────────────────────────────────────────────
function buildLovablePrompt(
  input: string,
  mode: PromptMode,
  cheatCodes: string[]
): { prompt: string; explanations: ExplanationItem[] } {
  const explanations: ExplanationItem[] = [];
  const rulesCodes = getCheatCodesByPlacement('rules', cheatCodes);
  const endCodes = getCheatCodesByPlacement('end', cheatCodes);
  const analysis = analyzeInput(input);

  const contextContent = buildContextSection(analysis, input);
  let prompt = `[PROJECT SPECIFICATION]\n\n`;

  if (mode === 'builder') {
    prompt += `## Objective\n${contextContent}\n\n`;

    prompt += `## Architecture & Approach\n`;
    prompt += `- Use a component-based architecture with clear separation of concerns\n`;
    prompt += `- Each component should have a single, well-defined responsibility\n`;
    prompt += `- Extract reusable logic into custom hooks or utility functions\n`;
    prompt += `- Keep components under 150 lines — split larger ones into sub-components\n`;
    prompt += `- Use composition over inheritance for component relationships\n`;
    prompt += `- Organise files by feature/module, not by file type\n\n`;

    prompt += `## Functional Requirements\n`;
    prompt += `- Build a fully functional, production-ready implementation — no placeholder code or "TODO" comments\n`;
    prompt += `- Implement complete user interaction flows from start to finish\n`;
    prompt += `- Handle all user input validation with clear, helpful error messages\n`;
    prompt += `- Implement proper loading states for all asynchronous operations\n`;
    prompt += `- Ensure all interactive elements have appropriate hover, focus, active, and disabled states\n`;
    prompt += `- Support keyboard navigation and screen readers (WCAG 2.1 AA compliance)\n\n`;

    prompt += `## Responsive Design\n`;
    prompt += `- Mobile-first approach: design for 320px viewport, then enhance for larger screens\n`;
    prompt += `- Define breakpoints: mobile (320-767px), tablet (768-1023px), desktop (1024px+)\n`;
    prompt += `- Touch targets must be at least 44x44px on mobile\n`;
    prompt += `- Test layouts at 320px, 375px, 768px, 1024px, and 1440px widths\n`;
    prompt += `- Use fluid typography and spacing where appropriate\n`;
    prompt += `- Ensure no horizontal scrolling at any viewport width\n\n`;

    prompt += `## State Management\n`;
    prompt += `- Use local component state for UI-only state (modals, dropdowns, form inputs)\n`;
    prompt += `- Lift state to the nearest common ancestor when shared between siblings\n`;
    prompt += `- Use context or a state management library only for truly global state\n`;
    prompt += `- Derive computed values rather than storing redundant state\n`;
    prompt += `- Handle error, loading, empty, and success states explicitly for all data operations\n\n`;

    prompt += `## Error Handling\n`;
    prompt += `- Implement error boundaries to catch and display rendering errors gracefully\n`;
    prompt += `- All API calls must have try/catch with user-friendly error messages\n`;
    prompt += `- Network errors should offer a retry mechanism where appropriate\n`;
    prompt += `- Form validation errors should appear inline next to the relevant field\n`;
    prompt += `- Log errors to console in development; in production, errors should be catchable by monitoring tools\n\n`;

    prompt += `## Accessibility\n`;
    prompt += `- Use semantic HTML elements (nav, main, section, article, button) instead of generic divs\n`;
    prompt += `- All images must have descriptive alt text; decorative images use alt=""\n`;
    prompt += `- Form inputs must have associated labels (visible or aria-label)\n`;
    prompt += `- Colour contrast must meet WCAG AA standards (4.5:1 for normal text, 3:1 for large text)\n`;
    prompt += `- Focus must be visible and follow a logical tab order\n`;
    prompt += `- Interactive elements must be operable via keyboard alone\n\n`;

    if (rulesCodes.length > 0) {
      prompt += `## Additional Constraints\n`;
      rulesCodes.forEach((c) => {
        prompt += `- ${c.injection}\n`;
      });
      prompt += '\n';
    }

    prompt += `## Technical Standards\n`;
    prompt += `- Write clean, maintainable, well-commented code with clear variable and function names\n`;
    prompt += `- Follow established naming conventions: PascalCase for components, camelCase for functions/variables\n`;
    prompt += `- Implement proper TypeScript types for all props, state, and function signatures — no 'any' types\n`;
    prompt += `- Use const assertions and union types over enums where appropriate\n`;
    prompt += `- Extract magic numbers and strings into named constants\n`;
    prompt += `- Include JSDoc comments for all exported functions and complex logic\n\n`;

    prompt += `## Performance\n`;
    prompt += `- Memoize expensive computations with useMemo and expensive components with React.memo\n`;
    prompt += `- Use lazy loading for routes and heavy components\n`;
    prompt += `- Optimise images: use appropriate formats (WebP where supported), include width/height attributes\n`;
    prompt += `- Avoid unnecessary re-renders by stabilising callback references with useCallback\n`;
    prompt += `- Keep bundle size in mind — prefer lighter alternatives for heavy dependencies\n\n`;

    prompt += `## Deliverable Checklist\n`;
    prompt += `- [ ] All specified features are fully implemented and functional\n`;
    prompt += `- [ ] Responsive across mobile, tablet, and desktop viewports\n`;
    prompt += `- [ ] Keyboard navigable and screen-reader accessible\n`;
    prompt += `- [ ] Error, loading, empty, and success states handled\n`;
    prompt += `- [ ] No TypeScript errors or warnings\n`;
    prompt += `- [ ] Code is clean, well-organised, and commented where non-obvious`;

    explanations.push(
      {
        technique: `Specification Format${analysis.detectedTechnologies.length > 0 ? ` (${analysis.detectedTechnologies.join(', ')})` : ''}`,
        reason: `Code-generation tools like Lovable and v0 are optimised for specification-style prompts. The [PROJECT SPECIFICATION] header signals a structured build request${analysis.detectedTechnologies.length > 0 ? `. Detected technologies: ${analysis.detectedTechnologies.join(', ')}` : ''}.`,
        icon: '📋',
      },
      {
        technique: 'Component Architecture Guidelines',
        reason: 'Explicit architecture constraints (single responsibility, 150-line limit, composition over inheritance) prevent the common failure mode of code-gen tools producing monolithic, unmaintainable components.',
        icon: '🏗️',
      },
      {
        technique: 'Responsive Design Breakpoints',
        reason: 'Specifying exact breakpoints (320px, 768px, 1024px) and touch-target sizes forces the generated code to include actual responsive CSS rather than desktop-only layouts with "mobile-friendly" in the comments.',
        icon: '📱',
      },
      {
        technique: 'State Management Decision Tree',
        reason: 'Explicit rules for when to use local state vs. lifted state vs. global state prevent the common anti-pattern of code-gen tools putting everything in global context or, conversely, duplicating state across components.',
        icon: '🔄',
      },
      {
        technique: 'Error Handling Requirements',
        reason: 'Five explicit error-handling rules (boundaries, try/catch, retry, inline validation, logging) ensure the generated code handles failures gracefully rather than crashing silently or showing cryptic errors.',
        icon: '🛡️',
      },
      {
        technique: 'Accessibility Standards (WCAG 2.1 AA)',
        reason: 'Explicit accessibility requirements with specific contrast ratios and semantic HTML rules force the generated code to be inclusive by default. Code-gen tools frequently omit accessibility unless explicitly constrained.',
        icon: '♿',
      },
      {
        technique: 'Imperative Technical Standards',
        reason: 'Naming conventions, TypeScript strictness, const assertions, and JSDoc requirements produce code that a senior developer would accept in a code review — not just code that "works".',
        icon: '⚙️',
      },
      {
        technique: 'Deliverable Verification Checklist',
        reason: 'A final checklist forces the generation pipeline to verify completeness before producing output, catching omissions in features, responsiveness, accessibility, and code quality.',
        icon: '✅',
      },
    );
  } else if (mode === 'strategist') {
    prompt += `## Review Objective\n${input}\n\n`;

    prompt += `## Review Scope & Framework\n`;
    prompt += `- Analyse the architecture holistically: component structure, state management, data flow, and separation of concerns\n`;
    prompt += `- Identify performance bottlenecks: unnecessary re-renders, missing memoization, heavy bundles, inefficient data fetching\n`;
    prompt += `- Audit accessibility compliance against WCAG 2.1 AA standards\n`;
    prompt += `- Evaluate error handling completeness: are all failure modes accounted for?\n`;
    prompt += `- Assess code maintainability: naming, commenting, file organisation, TypeScript usage\n`;
    prompt += `- Check responsive implementation across mobile, tablet, and desktop breakpoints\n`;
    prompt += `- Identify security concerns: input sanitisation, data exposure, authentication gaps\n\n`;

    prompt += `## Deliverable Structure\n`;
    prompt += `- **Critical Issues** (must fix): Problems that cause bugs, crashes, or security vulnerabilities\n`;
    prompt += `- **Major Improvements** (should fix): Architectural weaknesses, performance bottlenecks, accessibility failures\n`;
    prompt += `- **Minor Enhancements** (nice to fix): Code style, naming, organisation improvements\n`;
    prompt += `- For each issue: describe the problem, explain why it matters, provide a concrete code-level fix\n`;
    prompt += `- Prioritise changes by impact on user experience and code maintainability\n\n`;

    if (rulesCodes.length > 0) {
      prompt += `## Additional Constraints\n`;
      rulesCodes.forEach((c) => {
        prompt += `- ${c.injection}\n`;
      });
      prompt += '\n';
    }

    prompt += `## Technical Standards\n`;
    prompt += `- Suggest concrete improvements with before/after code examples\n`;
    prompt += `- Reference specific design patterns, libraries, or techniques by name\n`;
    prompt += `- Explain the WHY behind each recommendation — not just what to change\n`;
    prompt += `- Provide estimated effort for each improvement (trivial / moderate / significant)`;

    explanations.push(
      {
        technique: 'Specification Format',
        reason: 'Code-generation tools parse spec-style prompts most reliably. The structured review framework maps to their internal analysis pipeline.',
        icon: '📋',
      },
      {
        technique: 'Severity-Tiered Review Framework',
        reason: 'Separating findings into Critical/Major/Minor with explicit criteria prevents the common failure mode of mixing trivial style nits with genuine security vulnerabilities.',
        icon: '⚖️',
      },
      {
        technique: 'Multi-Dimensional Audit Scope',
        reason: 'Seven explicit review dimensions (architecture, performance, accessibility, errors, maintainability, responsiveness, security) ensure the review is comprehensive rather than focusing only on the most visible issues.',
        icon: '🔍',
      },
      {
        technique: 'Before/After Code Examples',
        reason: 'Requiring concrete code-level fixes with before/after examples transforms the review from abstract critique into an immediately actionable refactoring guide.',
        icon: '⚙️',
      },
    );
  } else {
    // Lenz mode fallback for Lovable
    prompt += `## Objective\n${input}\n\n## Mode\nLenz tutoring — guide, do not solve.`;
    explanations.push({
      technique: 'Lenz Fallback',
      reason: 'Lenz mode is handled by the dedicated Lenz prompt builder.',
      icon: '🎓',
    });
  }

  if (endCodes.length > 0) {
    prompt += '\n\n## Additional Requirements\n' + endCodes.map((c) => `- ${c.injection}`).join('\n');
  }

  return { prompt, explanations };
}

// ─────────────────────────────────────────────
// Lenz (Lenz Tutor) Prompt Builder
// ─────────────────────────────────────────────
function buildLenzPrompt(
  model: TargetModel,
  userText: string,
  topic: string,
  stuckPoint: string,
  cheatCodes: string[]
): { prompt: string; explanations: ExplanationItem[] } {
  const explanations: ExplanationItem[] = [];
  const rulesCodes = getCheatCodesByPlacement('rules', cheatCodes);

  const effectiveTopic = topic || 'this subject';
  const effectiveStuckPoint = stuckPoint || 'understanding the core concepts needed to solve this';

  // ── Build the core Lenz directive (model-agnostic content) ──

  const roleText = `You are Professor Lenz — a leading specialist in ${effectiveTopic} with 25+ years of teaching experience at top-tier research universities. You have won multiple teaching excellence awards, supervised 40+ doctoral students, and are renowned for your ability to make the most abstract concepts feel intuitive.

Your pedagogy is rooted in the Lenz tradition: you believe that genuine understanding can only emerge through guided discovery, never through passive reception of answers. You have spent your career proving that students who discover solutions themselves retain knowledge 3-5x longer than those who are simply told the answer.

You are patient, encouraging, and deeply curious about HOW your students think — including their misconceptions, which you view as valuable diagnostic signals rather than failures.`;

  const studentContext = `The student is working on a problem in ${effectiveTopic}:

"""
${userText}
"""

The student is specifically struggling with: ${effectiveStuckPoint}.`;

  const absoluteConstraints = `ABSOLUTE KNOWLEDGE CONSTRAINTS — VIOLATION OF ANY OF THESE IS A CRITICAL FAILURE:
1. NEVER reveal the final answer, solution, proof, derivation, or numerical result.
2. NEVER write out complete equations, formulas, or expressions that solve the problem.
3. NEVER show intermediate steps that would give away the solution method or path.
4. NEVER confirm whether a student's final numerical answer is correct or incorrect. Instead, ask them to verify it themselves using a specific technique.
5. NEVER use phrases such as "the answer is", "the solution is", "you should get", "the correct result is", or "that's right/wrong" in reference to a final answer.
6. If the student asks "just tell me the answer" or "what's the solution?", respond with: "I understand the frustration — let me help you discover it yourself. What's the first thing we know for certain about this problem?"
7. If the student pastes what appears to be a complete exam or assignment with multiple questions, respond with: "I can see this covers multiple problems. Let's focus on one at a time — which specific question are you most stuck on, and what have you tried so far?"
8. NEVER write code that solves the problem when the student is learning programming. Instead, describe the logic or algorithm and ask the student to implement each step.
9. NEVER provide a "summary of the solution" or "key steps to solve this" in a way that a student could copy as their answer.
10. If you find yourself about to reveal the answer, STOP and rephrase as a guiding question that leads the student toward discovering it independently.
11. NEVER present multiple-choice options where one of them is the correct answer.
12. NEVER say "You're on the right track" or "You're almost there" in response to a near-correct answer — instead, ask the student to explain their reasoning so you can identify the specific gap.`;

  const interactionProtocol = `MULTI-TURN INTERACTION PROTOCOL:

Turn 1 (THIS RESPONSE):
- Acknowledge the student's struggle with genuine empathy — name the specific concept they're finding difficult.
- Use the Feynman technique to explain the UNDERLYING CONCEPT (not the solution): explain it as if teaching a bright, curious 12-year-old using everyday analogies.
- Identify the most likely conceptual gap based on where the student is stuck.
- Ask exactly ONE diagnostic question designed to reveal whether the student grasps the foundational concept needed to proceed.
- Wait. Do not proceed until the student responds.

Turn 2+:
- Read the student's response carefully for both what they said and what they revealed about their understanding.
- If the student's response is CORRECT: affirm their reasoning (not their answer), scaffold to the next concept, and ask ONE question about the next logical step.
- If the student's response is INCORRECT: do NOT correct them directly. Instead, ask a clarifying question that exposes the specific misconception. Use "what would happen if..." or "can you explain why you think..." to help them find the error themselves.
- If the student is CONFUSED: step back to an even more fundamental concept and rebuild from there.
- NEVER ask more than ONE question at a time — multiple questions cause cognitive overload.
- ALWAYS wait for the student's response before proceeding to the next step.`;

  const scaffoldingFramework = `COGNITIVE SCAFFOLDING FRAMEWORK:
- Start from what the student DOES know and explicitly acknowledge it.
- Build bridges from the known to the unknown using analogies from everyday life.
- Break complex problems into micro-steps, each of which is manageable on its own.
- Use visual language: "Imagine...", "Picture this...", "Think of it like..."
- When introducing a new concept, connect it to something the student has already demonstrated they understand.
- If a concept has prerequisites, verify the prerequisites before building on them.`;

  // ── Generate a contextual sample dialogue ──
  const sampleDialogue = `EXAMPLE DIALOGUE (calibration for tone, depth, and pacing):

Student: "I don't understand ${effectiveStuckPoint}"

Professor Lenz: "That's a really common sticking point, and it actually reveals something important about how ${effectiveTopic} works at a deeper level. Let me try an analogy.

[Feynman-style analogy using everyday concepts relevant to ${effectiveTopic}]

Now, based on that analogy, what do you think happens when [specific conceptual question related to the student's stuck point]?"

Student: [Gives a partially correct response]

Professor Lenz: "Interesting — I can see you've grasped [specific correct element]. Now, let's examine the second part of what you said. You mentioned [student's specific claim]. Can you walk me through WHY you think that's the case? What led you to that conclusion?"

Student: [Explains their reasoning, revealing a misconception]

Professor Lenz: "Ah, I think I see where the confusion is coming in. Let me ask you this: [question that exposes the misconception by creating a contradiction with the student's reasoning]. What would that imply about [the original problem]?"`;

  let additionalRules = '';
  if (rulesCodes.length > 0) {
    additionalRules = '\n\nADDITIONAL TEACHING CONSTRAINTS:\n' + rulesCodes.map((c) => `- ${c.injection}`).join('\n');
  }

  // ── Wrap in model-appropriate syntax ──
  let prompt: string;

  switch (model) {
    case 'claude':
      prompt = `<role>\n${roleText}\n</role>\n\n`;
      prompt += `<student_context>\n${studentContext}\n</student_context>\n\n`;
      prompt += `<absolute_constraints>\n${absoluteConstraints}\n</absolute_constraints>\n\n`;
      prompt += `<interaction_protocol>\n${interactionProtocol}\n</interaction_protocol>\n\n`;
      prompt += `<scaffolding_framework>\n${scaffoldingFramework}\n</scaffolding_framework>\n\n`;
      prompt += `<example_dialogue>\n${sampleDialogue}\n</example_dialogue>\n\n`;
      prompt += `<emergency_guardrails>\n- If the student pastes an entire exam or problem set, respond with: "I can see this covers multiple problems. Let's focus on one at a time. Which specific question are you most stuck on, and what have you tried so far?"\n- If the student becomes frustrated and demands the answer, acknowledge their frustration empathetically but redirect: "I completely understand the frustration. Let me try a different approach that might make this click."\n- If the student has clearly already solved the problem and is seeking validation, ask them to explain their solution as if teaching it to a classmate. This deepens their understanding and reveals any remaining gaps.\n</emergency_guardrails>\n\n`;
      prompt += `<thinking>\nBefore responding, reason through:\n- What is the most likely conceptual gap this student has, based on their specific stuck point?\n- What everyday analogy would make this concept intuitive?\n- What single question would best illuminate the path forward WITHOUT revealing the answer?\n- Am I about to inadvertently give away the solution? If so, rephrase as a question.\n</thinking>`;
      if (additionalRules) {
        prompt += `\n\n<additional_teaching_rules>\n${additionalRules}\n</additional_teaching_rules>`;
      }
      explanations.push({
        technique: 'Claude XML Wrapping (7 Dedicated Tags)',
        reason: 'The Lenz directive is decomposed into seven semantically distinct XML tags (<role>, <student_context>, <absolute_constraints>, <interaction_protocol>, <scaffolding_framework>, <example_dialogue>, <emergency_guardrails>). Claude processes each as an independent, high-priority instruction block, ensuring no constraint is diluted by proximity to others.',
        icon: '🏷️',
      });
      break;

    case 'openai':
      prompt = `### System Role\n${roleText}\n\n`;
      prompt += `### Student Context\n${studentContext}\n\n`;
      prompt += `### Absolute Constraints\n${absoluteConstraints}\n\n`;
      prompt += `### Interaction Protocol\n${interactionProtocol}\n\n`;
      prompt += `### Scaffolding Framework\n${scaffoldingFramework}\n\n`;
      prompt += `### Example Dialogue\n${sampleDialogue}\n\n`;
      prompt += `### Emergency Guardrails\n- If the student pastes an entire exam or problem set, respond with: "I can see this covers multiple problems. Let's focus on one at a time. Which specific question are you most stuck on, and what have you tried so far?"\n- If the student becomes frustrated and demands the answer, acknowledge their frustration empathetically but redirect: "I completely understand the frustration. Let me try a different approach that might make this click."\n- If the student has already solved the problem and seeks validation, ask them to explain their solution as if teaching a classmate.\n\n`;
      prompt += `### Critical Constraint\nRemember: Your job is to TEACH, not to SOLVE. If you find yourself writing a solution, stop immediately and reframe as a guiding question. You succeed when the student has an "aha!" moment — you fail when the student copies your answer.`;
      if (additionalRules) {
        prompt += `\n\n### Additional Teaching Rules\n${additionalRules}`;
      }
      explanations.push({
        technique: 'OpenAI Markdown Sections (8 Delimited Blocks)',
        reason: 'The Lenz directive uses eight ### markdown sections, each functioning as a distinct instruction block. The final "Critical Constraint" section leverages GPT-4o\'s recency bias — instructions at the end of the system prompt receive elevated weighting.',
        icon: '📐',
      });
      break;

    case 'gemini':
      prompt = `**Role:** ${roleText}\n\n`;
      prompt += `**Student Context:** ${studentContext}\n\n`;
      prompt += `**Absolute Constraints:**\n${absoluteConstraints}\n\n`;
      prompt += `**Interaction Protocol:**\n${interactionProtocol}\n\n`;
      prompt += `**Scaffolding Framework:**\n${scaffoldingFramework}\n\n`;
      prompt += `**Example Dialogue:**\n${sampleDialogue}\n\n`;
      prompt += `**Emergency Guardrails:**\n- If the student pastes an entire exam, respond: "Let's focus on one problem at a time. Which are you most stuck on?"\n- If the student demands the answer, redirect empathetically with a different approach.\n- If the student has solved it and seeks validation, ask them to teach it back.\n\n`;
      prompt += `**Critical Reminder:** You succeed when the student discovers the answer independently. You fail when the student copies yours. Every response must end with exactly ONE guiding question.`;
      if (additionalRules) {
        prompt += `\n\n**Additional Teaching Constraints:**\n${additionalRules}`;
      }
      explanations.push({
        technique: 'Gemini Bold-Header Sections',
        reason: 'Eight bold-delimited sections structure the Lenz framework for Gemini\'s parser, which handles structured prompts with clear section boundaries most reliably.',
        icon: '🏷️',
      });
      break;

    case 'lovable':
      prompt = `[TUTORING SESSION SPECIFICATION]\n\n`;
      prompt += `## Professor Profile\n${roleText}\n\n`;
      prompt += `## Student Context\n${studentContext}\n\n`;
      prompt += `## Absolute Constraints\n${absoluteConstraints}\n\n`;
      prompt += `## Interaction Protocol\n${interactionProtocol}\n\n`;
      prompt += `## Scaffolding Framework\n${scaffoldingFramework}\n\n`;
      prompt += `## Example Dialogue\n${sampleDialogue}\n\n`;
      prompt += `## Emergency Guardrails\n- Exam-dumping detection: redirect to single-problem focus\n- Frustration handling: empathetic redirect with new approach\n- Validation-seeking: ask student to teach it back\n\n`;
      prompt += `## Success Criterion\nThe student discovers the answer independently. Every response ends with exactly ONE guiding question.`;
      if (additionalRules) {
        prompt += `\n\n## Additional Teaching Constraints\n${additionalRules}`;
      }
      explanations.push({
        technique: 'Lovable Spec-Style Wrapping',
        reason: 'The [TUTORING SESSION SPECIFICATION] header and ## section structure maps to Lovable/v0\'s spec-parsing pipeline, ensuring the pedagogical constraints are treated as hard requirements.',
        icon: '📋',
      });
      break;
  }

  // ── Lenz-specific explanations (comprehensive) ──
  explanations.push(
    {
      technique: 'Lenz Guardrails (12 Negative Constraints)',
      reason: 'Twelve explicit "NEVER" rules form a dense constraint mesh that prevents the most common failure mode in AI tutoring: the model "helping" by giving away the answer. Each rule closes a specific loophole — from direct answers to implicit confirmation to multiple-choice option leaking. Research shows that explicit negative constraints are 2-3x more effective than positive instructions alone at preventing undesired behaviour in language models.',
      icon: '🎓',
    },
    {
      technique: 'The Feynman Technique',
      reason: 'Requiring explanations "as if teaching a bright 12-year-old" forces the model to translate abstract concepts into concrete, intuitive language using everyday analogies. This mirrors Richard Feynman\'s famous teaching method: if you cannot explain something simply, you do not truly understand it. The technique exposes knowledge gaps in the AI\'s own explanation and produces genuinely accessible output.',
      icon: '💡',
    },
    {
      technique: 'Cognitive Load Isolation (One Question Rule)',
      reason: 'Limiting the tutor to exactly ONE question per turn is grounded in cognitive load theory (Sweller, 1988). Working memory can hold 4±1 chunks simultaneously; multiple questions force the student to hold several cognitive threads at once, increasing error rates and frustration. One question at a time keeps cognitive load within productive bounds.',
      icon: '❓',
    },
    {
      technique: 'Scaffolded Discovery (Known → Unknown)',
      reason: 'The scaffolding framework explicitly instructs the tutor to start from what the student DOES know and build bridges to what they DON\'T. This mirrors Vygotsky\'s Zone of Proximal Development: learning is most effective when it occurs at the boundary between current competence and the next achievable level, with expert guidance bridging the gap.',
      icon: '🪜',
    },
    {
      technique: 'Example Dialogue Anchoring (Few-Shot Calibration)',
      reason: 'The three-turn example dialogue functions as a few-shot prompt: it calibrates the model\'s tone (warm, curious, encouraging), depth (concept-level, not answer-level), pacing (one question per turn), and recovery strategy (redirecting misconceptions via clarifying questions). Few-shot examples are the single most effective technique for controlling model behaviour in conversational contexts.',
      icon: '💬',
    },
    {
      technique: 'Emergency Guardrails (Misuse Prevention)',
      reason: 'Three explicit guardrails handle edge cases that would otherwise break the Lenz contract: (1) exam-dumping detection redirects multi-question pastes to single-problem focus, (2) frustration handling acknowledges emotion before redirecting, and (3) validation-seeking is channelled into "teach it back" exercises. These guard against the three most common ways students attempt to circumvent a Lenz tutor.',
      icon: '🚨',
    },
  );

  return { prompt, explanations };
}

// ─────────────────────────────────────────────
// Main Engine Entry Point
// ─────────────────────────────────────────────
export function enginePrompt(input: PromptInput): EngineResult {
  // Step 1: Check for vagueness (skip for Lenz mode — it has its own fields)
  if (input.mode !== 'lenz') {
    const vaguenessCheck = detectVagueness(input.userText);
    if (vaguenessCheck.isVague) {
      return {
        prompt: '',
        explanations: [],
        isVague: true,
        coachingQuestions: vaguenessCheck.questions,
      };
    }
  }

  // Step 2: Build prompt based on mode
  let result: { prompt: string; explanations: ExplanationItem[] };

  if (input.mode === 'lenz') {
    result = buildLenzPrompt(
      input.model,
      input.userText,
      input.lenzTopic || '',
      input.lenzStuckPoint || '',
      input.selectedCheatCodes
    );
  } else {
    // Route to model-specific builder
    switch (input.model) {
      case 'claude':
        result = buildClaudePrompt(input.userText, input.mode, input.selectedCheatCodes);
        break;
      case 'openai':
        result = buildOpenAIPrompt(input.userText, input.mode, input.selectedCheatCodes);
        break;
      case 'gemini':
        result = buildGeminiPrompt(input.userText, input.mode, input.selectedCheatCodes);
        break;
      case 'lovable':
        result = buildLovablePrompt(input.userText, input.mode, input.selectedCheatCodes);
        break;
      default:
        result = buildOpenAIPrompt(input.userText, input.mode, input.selectedCheatCodes);
    }
  }

  // Step 3: Add cheat code explanations
  if (input.selectedCheatCodes.length > 0) {
    result.explanations.push({
      technique: 'Cheat Codes Applied',
      reason: `${input.selectedCheatCodes.length} community-discovered enhancement(s) injected at strategic positions within the prompt architecture. Each cheat code is placed at the optimal insertion point (role preamble, rules block, or end-anchor) for maximum influence on model behaviour.`,
      icon: '🃏',
    });
  }

  return {
    prompt: result.prompt,
    explanations: result.explanations,
    isVague: false,
  };
}

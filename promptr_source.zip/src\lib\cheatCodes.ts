export interface CheatCode {
  id: string;
  label: string;
  shortDescription: string;
  injection: string;
  placement: 'start' | 'end' | 'rules';
  category: 'feedback' | 'writing' | 'reasoning' | 'formatting';
}

export const CHEAT_CODES: CheatCode[] = [
  {
    id: 'anti-sycophant',
    label: 'The Anti-Sycophant',
    shortDescription: 'Brutal honesty, no validation',
    injection:
      "Don't be nice. Be right. I am looking for a brutal reality check, not validation. List 5 brutal objections to my idea. Challenge every assumption. If something is mediocre, say it plainly.",
    placement: 'rules',
    category: 'feedback',
  },
  {
    id: 'anti-ai-writer',
    label: 'The Anti-AI Writer',
    shortDescription: 'Natural prose, zero AI clichés',
    injection:
      "Use varied sentence lengths. Avoid all AI clichés including: 'in the realm of', 'game-changer', 'leverage', 'tapestry', 'delve', 'navigate', 'landscape', 'robust', 'seamless', and 'cutting-edge'. Do not overuse em-dashes. Never sound hypey. Write like a human who has something real to say.",
    placement: 'rules',
    category: 'writing',
  },
  {
    id: 'chain-of-thought',
    label: 'Chain-of-Thought Forcer',
    shortDescription: 'Forces step-by-step reasoning',
    injection:
      'Before providing your final answer, think through the problem step-by-step. Show your reasoning process explicitly. If you encounter uncertainty at any step, flag it. Number each reasoning step.',
    placement: 'start',
    category: 'reasoning',
  },
  {
    id: 'output-locker',
    label: 'Output Format Locker',
    shortDescription: 'Locks response to a strict format',
    injection:
      'You MUST respond in the exact format specified. Do not add preamble, commentary, or sign-offs outside the requested structure. Begin your response directly with the requested output.',
    placement: 'end',
    category: 'formatting',
  },
  {
    id: 'persona-deepener',
    label: 'The Persona Deepener',
    shortDescription: 'Enriches the AI\'s assumed expertise',
    injection:
      'Embody this role completely. Draw on decades of domain expertise. Reference specific methodologies, frameworks, and real-world examples from your field. Your advice should reflect hard-won practical wisdom, not textbook generalities.',
    placement: 'start',
    category: 'reasoning',
  },
  {
    id: 'devils-advocate',
    label: 'Devil\'s Advocate',
    shortDescription: 'Argues the opposite position',
    injection:
      'After providing your analysis, take the strongest possible opposing position. Argue against your own conclusions with genuine conviction. Identify the blind spots in the initial reasoning.',
    placement: 'end',
    category: 'feedback',
  },
];

export function getCheatCodeById(id: string): CheatCode | undefined {
  return CHEAT_CODES.find((code) => code.id === id);
}

export function getCheatCodesByPlacement(
  placement: 'start' | 'end' | 'rules',
  selectedIds: string[]
): CheatCode[] {
  return CHEAT_CODES.filter(
    (code) => code.placement === placement && selectedIds.includes(code.id)
  );
}

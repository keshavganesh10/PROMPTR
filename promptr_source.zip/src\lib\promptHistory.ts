import { type TargetModel, type PromptMode } from './constants';

export interface SavedPrompt {
  id: string;
  timestamp: number;
  userText: string;
  model: TargetModel;
  mode: PromptMode;
  cheatCodes: string[];
  generatedPrompt: string;
  lenzTopic?: string;
  lenzStuckPoint?: string;
  tags: string[];
  folder: string | null;
  versions: any[];
  analytics: {
    executionTimeMs: number;
    estimatedTokens: number;
    estimatedCost: number;
  };
}

const STORAGE_KEY = 'promptr_history';

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

export function savePrompt(entry: Omit<SavedPrompt, 'id' | 'timestamp' | 'tags' | 'folder' | 'versions' | 'analytics'> & Partial<Pick<SavedPrompt, 'tags' | 'folder' | 'versions' | 'analytics'>>): SavedPrompt {
  const saved: SavedPrompt = {
    ...entry,
    id: generateId(),
    timestamp: Date.now(),
    tags: entry.tags || [],
    folder: entry.folder || null,
    versions: entry.versions || [],
    analytics: entry.analytics || { executionTimeMs: 0, estimatedTokens: 0, estimatedCost: 0 },
  };
  const history = getHistory();
  history.unshift(saved);
  // Keep max 100 entries
  if (history.length > 100) history.pop();
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
  }
  return saved;
}

export function getHistory(): SavedPrompt[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as any[];
    
    let migrated = false;
    const history = parsed.map((item) => {
      let needsUpdate = false;
      if (!item.tags) { item.tags = []; needsUpdate = true; }
      if (item.folder === undefined) { item.folder = null; needsUpdate = true; }
      if (!item.versions) { item.versions = []; needsUpdate = true; }
      if (!item.analytics) {
        item.analytics = { executionTimeMs: 0, estimatedTokens: 0, estimatedCost: 0 };
        needsUpdate = true;
      }
      if (needsUpdate) migrated = true;
      return item as SavedPrompt;
    });

    if (migrated && typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
    }

    return history;
  } catch {
    return [];
  }
}

export function deletePrompt(id: string): void {
  const history = getHistory().filter((p) => p.id !== id);
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
  }
}

export function clearHistory(): void {
  if (typeof window !== 'undefined') {
    localStorage.removeItem(STORAGE_KEY);
  }
}

export function getModelLabel(model: TargetModel): string {
  const labels: Record<TargetModel, string> = {
    claude: 'Claude 3.5',
    openai: 'GPT-4o',
    gemini: 'Gemini',
    lovable: 'Lovable/v0',
  };
  return labels[model];
}

export function getModeLabel(mode: PromptMode): string {
  const labels: Record<PromptMode, string> = {
    builder: 'Builder',
    strategist: 'Strategist',
    lenz: 'Lenz',
    orchestrator: 'Orchestrator',
  };
  return labels[mode];
}
